package com.example.ui.screens.invoice

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.RentalBillEntity
import com.example.ui.screens.dashboard.formatAmount
import com.example.ui.theme.ChamaraBgDark
import com.example.ui.theme.ChamaraBorder
import com.example.ui.theme.ChamaraGold
import com.example.ui.theme.ChamaraLime
import com.example.ui.theme.ChamaraLimeBright
import com.example.ui.theme.ChamaraSurfaceCard
import com.example.ui.theme.ChamaraSurfaceDark
import com.example.ui.theme.StatusBalanceDue
import com.example.ui.theme.StatusPaidCleared
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.ResortViewModel

@Composable
fun InvoiceScreen(
    bill: RentalBillEntity,
    viewModel: ResortViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val payments by viewModel.selectedBillPayments.collectAsStateWithLifecycle()

    val currency = settings.currencySymbol

    fun shareInvoice() {
        val invoiceText = buildString {
            appendLine("========================================")
            appendLine("        ${settings.resortName.uppercase()}        ")
            appendLine("    ${settings.resortAddress}")
            appendLine("    Tel: ${settings.telephone1} | ${settings.telephone2}")
            appendLine("========================================")
            appendLine("INVOICE / BILL: ${bill.invoiceNumber}")
            appendLine("DATE: ${bill.checkInDate} ${bill.checkInTime}")
            appendLine("ROOM: ${bill.roomNumber}")
            appendLine("GUEST: ${bill.guestName}")
            appendLine("PHONE: ${bill.guestPhone}")
            if (bill.guestIdOrPassport.isNotBlank()) appendLine("NIC/PASSPORT: ${bill.guestIdOrPassport}")
            appendLine("RENTAL TYPE: ${bill.rentalType} (${bill.units} units @ $currency ${formatAmount(bill.ratePerUnit)})")
            appendLine("----------------------------------------")
            appendLine("Room Charge:        $currency ${formatAmount(bill.roomCharge)}")
            if (bill.extraCharges > 0) appendLine("Extras (${bill.extraChargesNote}): $currency ${formatAmount(bill.extraCharges)}")
            if (bill.discount > 0) appendLine("Discount:          -$currency ${formatAmount(bill.discount)}")
            appendLine("TOTAL AMOUNT:       $currency ${formatAmount(bill.totalAmount)}")
            appendLine("PAID TO DATE:       $currency ${formatAmount(bill.paidAmount)}")
            appendLine("BALANCE DUE:        $currency ${formatAmount(bill.balance)}")
            appendLine("STATUS:             ${bill.status}")
            appendLine("----------------------------------------")
            if (bill.checkOutDate.isNotBlank()) {
                appendLine("Check-Out: ${bill.checkOutDate} ${bill.checkOutTime}")
            }
            appendLine(settings.invoiceFooterText)
            appendLine("========================================")
        }

        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, invoiceText)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "Share Chamara Resorts Invoice")
        context.startActivity(shareIntent)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ChamaraBgDark),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // App bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Official Invoice", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }

                Button(
                    onClick = { shareInvoice() },
                    colors = ButtonDefaults.buttonColors(containerColor = ChamaraLime, contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("share_invoice_button")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Share / Print", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // The Formal Receipt / Folio
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header
                    Icon(Icons.Default.Hotel, contentDescription = null, tint = Color(0xFF1E293B), modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = settings.resortName.uppercase(),
                        color = Color(0xFF0F172A),
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = settings.resortAddress,
                        color = Color(0xFF475569),
                        fontSize = 12.sp
                    )
                    Text(
                        text = "Tel: ${settings.telephone1} | ${settings.telephone2}",
                        color = Color(0xFF475569),
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE2E8F0)))
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "GUEST FOLIO / OFFICIAL BILL",
                        color = Color(0xFF0F172A),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Meta Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            ReceiptMetaItem(label = "INVOICE NO", value = bill.invoiceNumber)
                            ReceiptMetaItem(label = "ROOM", value = bill.roomNumber)
                            ReceiptMetaItem(label = "RENTAL TYPE", value = "${bill.rentalType} (${bill.units} units)")
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            ReceiptMetaItem(label = "DATE", value = bill.checkInDate, alignRight = true)
                            ReceiptMetaItem(label = "CHECK-IN", value = bill.checkInTime, alignRight = true)
                            ReceiptMetaItem(label = "STATUS", value = bill.status, alignRight = true)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE2E8F0)))
                    Spacer(modifier = Modifier.height(8.dp))

                    // Guest details
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("BILLED TO:", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(bill.guestName, color = Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Phone: ${bill.guestPhone}", color = Color(0xFF334155), fontSize = 12.sp)
                            if (bill.guestIdOrPassport.isNotBlank()) {
                                Text("ID/Passport: ${bill.guestIdOrPassport}", color = Color(0xFF64748B), fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Itemized Table
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            ReceiptTableLine(
                                desc = "${bill.rentalType} Rental (${bill.units} x $currency ${formatAmount(bill.ratePerUnit)})",
                                amount = "$currency ${formatAmount(bill.roomCharge)}"
                            )

                            if (bill.extraCharges > 0) {
                                ReceiptTableLine(
                                    desc = "Extras: ${if (bill.extraChargesNote.isNotBlank()) bill.extraChargesNote else "Add-ons"}",
                                    amount = "$currency ${formatAmount(bill.extraCharges)}"
                                )
                            }

                            if (bill.discount > 0) {
                                ReceiptTableLine(
                                    desc = "Discount Applied",
                                    amount = "- $currency ${formatAmount(bill.discount)}"
                                )
                            }

                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFCBD5E1)))

                            ReceiptTableLine(
                                desc = "TOTAL BILL AMOUNT",
                                amount = "$currency ${formatAmount(bill.totalAmount)}",
                                isBold = true
                            )

                            ReceiptTableLine(
                                desc = "Amount Received",
                                amount = "$currency ${formatAmount(bill.paidAmount)}"
                            )

                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFCBD5E1)))

                            ReceiptTableLine(
                                desc = "BALANCE PAYABLE",
                                amount = "$currency ${formatAmount(bill.balance)}",
                                isBold = true,
                                highlight = bill.balance > 0
                            )
                        }
                    }

                    if (payments.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "PAYMENT SUMMARY",
                            color = Color(0xFF64748B),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.Start)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        payments.forEach { p ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${p.paymentDate} • ${p.paymentMethod} ${if (p.referenceNote.isNotBlank()) "(${p.referenceNote})" else ""}", color = Color(0xFF475569), fontSize = 11.sp)
                                Text("$currency ${formatAmount(p.amount)}", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE2E8F0)))
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = settings.invoiceFooterText,
                        color = Color(0xFF64748B),
                        fontSize = 11.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun ReceiptMetaItem(label: String, value: String, alignRight: Boolean = false) {
    Column(horizontalAlignment = if (alignRight) Alignment.End else Alignment.Start) {
        Text(label, color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        Text(value, color = Color(0xFF0F172A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ReceiptTableLine(
    desc: String,
    amount: String,
    isBold: Boolean = false,
    highlight: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = desc,
            color = if (isBold) Color(0xFF0F172A) else Color(0xFF475569),
            fontSize = if (isBold) 13.sp else 12.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = amount,
            color = if (highlight) Color(0xFFE11D48) else if (isBold) Color(0xFF0F172A) else Color(0xFF334155),
            fontSize = if (isBold) 14.sp else 12.sp,
            fontWeight = if (isBold) FontWeight.Black else FontWeight.SemiBold
        )
    }
}

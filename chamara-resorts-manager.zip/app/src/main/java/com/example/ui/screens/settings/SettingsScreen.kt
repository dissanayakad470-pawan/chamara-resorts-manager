package com.example.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ChamaraBrandHeader
import com.example.ui.screens.dashboard.PaddingHeader
import com.example.ui.screens.rooms.roomTextFieldColors
import com.example.ui.theme.ChamaraBgDark
import com.example.ui.theme.ChamaraBorder
import com.example.ui.theme.ChamaraLime
import com.example.ui.theme.ChamaraSurfaceCard
import com.example.ui.theme.ChamaraSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.ResortViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: ResortViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Form states
    var resortName by remember { mutableStateOf(settings.resortName) }
    var resortAddress by remember { mutableStateOf(settings.resortAddress) }
    var telephone1 by remember { mutableStateOf(settings.telephone1) }
    var telephone2 by remember { mutableStateOf(settings.telephone2) }

    var currencySymbol by remember { mutableStateOf(settings.currencySymbol) }
    var defaultNightPrice by remember { mutableStateOf(settings.defaultNightPrice.toString()) }
    var defaultDayPrice by remember { mutableStateOf(settings.defaultDayPrice.toString()) }
    var defaultShortTimePrice by remember { mutableStateOf(settings.defaultShortTimePrice.toString()) }
    var defaultHourlyPrice by remember { mutableStateOf(settings.defaultHourlyPrice.toString()) }

    var invoicePrefix by remember { mutableStateOf(settings.invoicePrefix) }
    var nextInvoiceSeq by remember { mutableStateOf(settings.nextInvoiceSeq.toString()) }
    var invoiceFooterText by remember { mutableStateOf(settings.invoiceFooterText) }

    LaunchedEffect(settings) {
        resortName = settings.resortName
        resortAddress = settings.resortAddress
        telephone1 = settings.telephone1
        telephone2 = settings.telephone2
        currencySymbol = settings.currencySymbol
        defaultNightPrice = settings.defaultNightPrice.toString()
        defaultDayPrice = settings.defaultDayPrice.toString()
        defaultShortTimePrice = settings.defaultShortTimePrice.toString()
        defaultHourlyPrice = settings.defaultHourlyPrice.toString()
        invoicePrefix = settings.invoicePrefix
        nextInvoiceSeq = settings.nextInvoiceSeq.toString()
        invoiceFooterText = settings.invoiceFooterText
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(ChamaraBgDark),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            item {
                ChamaraBrandHeader(compact = true)
            }

            // Section 1: Business Identity & Contact
            item {
                PaddingHeader(title = "RESORT & CONTACT INFORMATION")
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = resortName,
                            onValueChange = { resortName = it },
                            label = { Text("Hotel / Resort Name") },
                            leadingIcon = { Icon(Icons.Default.Business, contentDescription = null, tint = ChamaraLime) },
                            colors = roomTextFieldColors(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("settings_resort_name")
                        )

                        OutlinedTextField(
                            value = resortAddress,
                            onValueChange = { resortAddress = it },
                            label = { Text("Resort Address (Printed on Bills)") },
                            leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = ChamaraLime) },
                            colors = roomTextFieldColors(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("settings_resort_address")
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = telephone1,
                                onValueChange = { telephone1 = it },
                                label = { Text("Telephone 1") },
                                leadingIcon = { Icon(Icons.Default.Call, contentDescription = null, tint = ChamaraLime) },
                                colors = roomTextFieldColors(),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("settings_telephone_1")
                            )

                            OutlinedTextField(
                                value = telephone2,
                                onValueChange = { telephone2 = it },
                                label = { Text("Telephone 2") },
                                leadingIcon = { Icon(Icons.Default.Call, contentDescription = null, tint = ChamaraLime) },
                                colors = roomTextFieldColors(),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("settings_telephone_2")
                            )
                        }
                    }
                }
            }

            // Section 2: Default Rental Prices
            item {
                Spacer(modifier = Modifier.height(14.dp))
                PaddingHeader(title = "DEFAULT RENTAL RATES")
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = currencySymbol,
                                onValueChange = { currencySymbol = it },
                                label = { Text("Currency") },
                                colors = roomTextFieldColors(),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = defaultNightPrice,
                                onValueChange = { defaultNightPrice = it },
                                label = { Text("Night Price") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = roomTextFieldColors(),
                                modifier = Modifier.weight(1.5f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = defaultDayPrice,
                                onValueChange = { defaultDayPrice = it },
                                label = { Text("Day Price") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = roomTextFieldColors(),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = defaultShortTimePrice,
                                onValueChange = { defaultShortTimePrice = it },
                                label = { Text("Short Time Price") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = roomTextFieldColors(),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = defaultHourlyPrice,
                                onValueChange = { defaultHourlyPrice = it },
                                label = { Text("Hourly Price") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = roomTextFieldColors(),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Section 3: Invoice Settings
            item {
                Spacer(modifier = Modifier.height(14.dp))
                PaddingHeader(title = "INVOICE & BILL FORMAT")
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = invoicePrefix,
                                onValueChange = { invoicePrefix = it },
                                label = { Text("Invoice Prefix") },
                                colors = roomTextFieldColors(),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = nextInvoiceSeq,
                                onValueChange = { nextInvoiceSeq = it },
                                label = { Text("Next Sequence Number") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = roomTextFieldColors(),
                                modifier = Modifier.weight(1.5f)
                            )
                        }

                        OutlinedTextField(
                            value = invoiceFooterText,
                            onValueChange = { invoiceFooterText = it },
                            label = { Text("Invoice Footer Message") },
                            colors = roomTextFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Save Settings Button
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        val updated = settings.copy(
                            resortName = resortName.trim(),
                            resortAddress = resortAddress.trim(),
                            telephone1 = telephone1.trim(),
                            telephone2 = telephone2.trim(),
                            currencySymbol = currencySymbol.trim(),
                            defaultNightPrice = defaultNightPrice.toDoubleOrNull() ?: settings.defaultNightPrice,
                            defaultDayPrice = defaultDayPrice.toDoubleOrNull() ?: settings.defaultDayPrice,
                            defaultShortTimePrice = defaultShortTimePrice.toDoubleOrNull() ?: settings.defaultShortTimePrice,
                            defaultHourlyPrice = defaultHourlyPrice.toDoubleOrNull() ?: settings.defaultHourlyPrice,
                            invoicePrefix = invoicePrefix.trim(),
                            nextInvoiceSeq = nextInvoiceSeq.toIntOrNull() ?: settings.nextInvoiceSeq,
                            invoiceFooterText = invoiceFooterText.trim()
                        )
                        viewModel.updateSettings(updated)
                        scope.launch {
                            snackbarHostState.showSnackbar("Settings saved successfully!")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ChamaraLime, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .height(52.dp)
                        .testTag("save_settings_button")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save Settings", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 80.dp)
        )
    }
}

package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ChamaraLime,
    onPrimary = Color.Black,
    primaryContainer = ChamaraLimeDark,
    onPrimaryContainer = ChamaraLimeBright,
    secondary = ChamaraGold,
    onSecondary = Color.Black,
    secondaryContainer = ChamaraSurfaceHover,
    onSecondaryContainer = ChamaraGold,
    tertiary = StatusReserved,
    background = ChamaraBgDark,
    onBackground = TextWhite,
    surface = ChamaraSurfaceDark,
    onSurface = TextWhite,
    surfaceVariant = ChamaraSurfaceCard,
    onSurfaceVariant = TextLight,
    outline = ChamaraBorder,
    error = StatusBalanceDue,
    onError = Color.White
)

@Composable
fun ChamaraResortsTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

// Keep backward compatibility if any preview references MyApplicationTheme
@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    ChamaraResortsTheme(content = content)
}

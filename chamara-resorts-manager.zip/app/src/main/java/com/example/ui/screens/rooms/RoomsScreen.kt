package com.example.ui.screens.rooms

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.RoomEntity
import com.example.ui.components.ChamaraBrandHeader
import com.example.ui.screens.dashboard.PaddingHeader
import com.example.ui.screens.dashboard.formatAmount
import com.example.ui.theme.ChamaraBgDark
import com.example.ui.theme.ChamaraBorder
import com.example.ui.theme.ChamaraGold
import com.example.ui.theme.ChamaraLime
import com.example.ui.theme.ChamaraLimeBright
import com.example.ui.theme.ChamaraSurfaceCard
import com.example.ui.theme.ChamaraSurfaceDark
import com.example.ui.theme.ChamaraSurfaceHover
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusOccupied
import com.example.ui.theme.StatusReserved
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.ResortViewModel

@Composable
fun RoomsScreen(
    viewModel: ResortViewModel,
    onBookRoom: (RoomEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val rooms by viewModel.filteredRooms.collectAsStateWithLifecycle()
    val allRooms by viewModel.allRooms.collectAsStateWithLifecycle()
    val currentFilter by viewModel.roomStatusFilter.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    var showAddEditDialog by remember { mutableStateOf(false) }
    var roomToEdit by remember { mutableStateOf<RoomEntity?>(null) }
    var roomToDelete by remember { mutableStateOf<RoomEntity?>(null) }

    val currency = settings.currencySymbol

    val filterOptions = listOf("ALL", "AVAILABLE", "OCCUPIED", "RESERVED")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ChamaraBgDark),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        item {
            ChamaraBrandHeader(compact = true)
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("ROOM & VILLA INVENTORY", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("${allRooms.size} Total Units Registered", color = TextMuted, fontSize = 12.sp)
                }

                Button(
                    onClick = {
                        roomToEdit = null
                        showAddEditDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ChamaraLime, contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("add_room_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Room", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        // Filter chips
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filterOptions) { filter ->
                    val isSelected = currentFilter == filter
                    val count = if (filter == "ALL") allRooms.size else allRooms.count { it.status.equals(filter, ignoreCase = true) }

                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setRoomStatusFilter(filter) },
                        label = { Text("$filter ($count)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ChamaraLime,
                            selectedLabelColor = Color.Black,
                            containerColor = ChamaraSurfaceCard,
                            labelColor = TextMuted
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            borderColor = if (isSelected) ChamaraLime else ChamaraBorder,
                            enabled = true,
                            selected = isSelected
                        )
                    )
                }
            }
        }

        if (rooms.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No rooms found for filter '$currentFilter'.",
                        color = TextMuted,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            items(rooms) { room ->
                RoomInventoryCard(
                    room = room,
                    currency = currency,
                    onBook = { onBookRoom(room) },
                    onEdit = {
                        roomToEdit = room
                        showAddEditDialog = true
                    },
                    onDelete = { roomToDelete = room },
                    onToggleStatus = { nextStatus ->
                        viewModel.setRoomStatus(room.id, nextStatus)
                    }
                )
            }
        }
    }

    if (showAddEditDialog) {
        AddEditRoomDialog(
            existingRoom = roomToEdit,
            currency = currency,
            onDismiss = { showAddEditDialog = false },
            onSave = { room ->
                if (roomToEdit == null) {
                    viewModel.addRoom(room)
                } else {
                    viewModel.updateRoom(room)
                }
                showAddEditDialog = false
            }
        )
    }

    if (roomToDelete != null) {
        AlertDialog(
            onDismissRequest = { roomToDelete = null },
            title = { Text("Delete Room?", color = TextWhite) },
            text = { Text("Are you sure you want to delete ${roomToDelete?.roomNumber}? This cannot be undone.", color = TextLight) },
            confirmButton = {
                Button(
                    onClick = {
                        roomToDelete?.let { viewModel.deleteRoom(it) }
                        roomToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { roomToDelete = null }) {
                    Text("Cancel", color = TextMuted)
                }
            },
            containerColor = ChamaraSurfaceDark
        )
    }
}

@Composable
fun RoomInventoryCard(
    room: RoomEntity,
    currency: String,
    onBook: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleStatus: (String) -> Unit
) {
    val statusColor = when (room.status.uppercase()) {
        "OCCUPIED" -> StatusOccupied
        "RESERVED" -> StatusReserved
        "MAINTENANCE" -> Color(0xFF6B7280)
        else -> StatusAvailable
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("room_card_${room.roomNumber}"),
        colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = room.roomNumber,
                        color = TextWhite,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(ChamaraSurfaceDark)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(room.floor, color = TextMuted, fontSize = 11.sp)
                    }
                }

                // Status Badge with clickable dropdown/toggle
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = statusColor.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.4f)),
                    modifier = Modifier.clickable {
                        val next = when (room.status.uppercase()) {
                            "AVAILABLE" -> "RESERVED"
                            "RESERVED" -> "MAINTENANCE"
                            "MAINTENANCE" -> "AVAILABLE"
                            else -> "AVAILABLE"
                        }
                        onToggleStatus(next)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = room.status,
                            color = statusColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = room.roomType,
                color = ChamaraLimeBright,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )

            if (room.amenities.isNotBlank()) {
                Text(
                    text = "Amenities: ${room.amenities}",
                    color = TextMuted,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Pricing Grid: Night, Day, Short Time, Hourly
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(ChamaraSurfaceDark)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                RateItem(label = "Night", price = room.defaultNightRate, currency = currency)
                RateItem(label = "Day", price = room.defaultDayRate, currency = currency)
                RateItem(label = "Short Time", price = room.defaultShortTimeRate, currency = currency)
                RateItem(label = "Hourly", price = room.defaultHourlyRate, currency = currency)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Room", tint = TextMuted, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Room", tint = TextDim, modifier = Modifier.size(16.dp))
                    }
                }

                Button(
                    onClick = onBook,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ChamaraLime,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("book_room_${room.roomNumber}")
                ) {
                    Text(
                        text = if (room.status == "AVAILABLE") "Check-In / Book" else "Create Bill",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
fun RateItem(label: String, price: Double, currency: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextMuted, fontSize = 10.sp)
        Text(
            text = "$currency ${formatAmount(price)}",
            color = TextLight,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
fun AddEditRoomDialog(
    existingRoom: RoomEntity?,
    currency: String,
    onDismiss: () -> Unit,
    onSave: (RoomEntity) -> Unit
) {
    var roomNumber by remember { mutableStateOf(existingRoom?.roomNumber ?: "") }
    var roomType by remember { mutableStateOf(existingRoom?.roomType ?: "Deluxe Double") }
    var floor by remember { mutableStateOf(existingRoom?.floor ?: "Ground Floor") }
    var nightRate by remember { mutableStateOf(existingRoom?.defaultNightRate?.toString() ?: "8500") }
    var dayRate by remember { mutableStateOf(existingRoom?.defaultDayRate?.toString() ?: "5000") }
    var shortTimeRate by remember { mutableStateOf(existingRoom?.defaultShortTimeRate?.toString() ?: "3500") }
    var hourlyRate by remember { mutableStateOf(existingRoom?.defaultHourlyRate?.toString() ?: "1200") }
    var amenities by remember { mutableStateOf(existingRoom?.amenities ?: "AC, King Bed, Hot Water, TV, Balcony") }
    var notes by remember { mutableStateOf(existingRoom?.notes ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (existingRoom == null) "Add New Room / Villa" else "Edit ${existingRoom.roomNumber}",
                color = TextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    OutlinedTextField(
                        value = roomNumber,
                        onValueChange = { roomNumber = it },
                        label = { Text("Room / Villa Name or Number") },
                        placeholder = { Text("e.g. Room 105, Villa B") },
                        colors = roomTextFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_room_number_input")
                    )
                }

                item {
                    OutlinedTextField(
                        value = roomType,
                        onValueChange = { roomType = it },
                        label = { Text("Room Type") },
                        placeholder = { Text("e.g. Deluxe AC, Suite, Cabana") },
                        colors = roomTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = floor,
                        onValueChange = { floor = it },
                        label = { Text("Floor / Wing") },
                        colors = roomTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Text("Rental Rates ($currency):", color = ChamaraLime, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = nightRate,
                            onValueChange = { nightRate = it },
                            label = { Text("Night Rate") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = roomTextFieldColors(),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = dayRate,
                            onValueChange = { dayRate = it },
                            label = { Text("Day Rate") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = roomTextFieldColors(),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = shortTimeRate,
                            onValueChange = { shortTimeRate = it },
                            label = { Text("Short Time") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = roomTextFieldColors(),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = hourlyRate,
                            onValueChange = { hourlyRate = it },
                            label = { Text("Hourly Rate") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = roomTextFieldColors(),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = amenities,
                        onValueChange = { amenities = it },
                        label = { Text("Amenities") },
                        colors = roomTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Internal Notes") },
                        colors = roomTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (roomNumber.isNotBlank()) {
                        val room = (existingRoom ?: RoomEntity(roomNumber = roomNumber.trim(), roomType = roomType.trim(), floor = floor.trim())).copy(
                            roomNumber = roomNumber.trim(),
                            roomType = roomType.trim(),
                            floor = floor.trim(),
                            defaultNightRate = nightRate.toDoubleOrNull() ?: 8500.0,
                            defaultDayRate = dayRate.toDoubleOrNull() ?: 5000.0,
                            defaultShortTimeRate = shortTimeRate.toDoubleOrNull() ?: 3500.0,
                            defaultHourlyRate = hourlyRate.toDoubleOrNull() ?: 1200.0,
                            amenities = amenities.trim(),
                            notes = notes.trim()
                        )
                        onSave(room)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ChamaraLime, contentColor = Color.Black),
                modifier = Modifier.testTag("dialog_save_room_button")
            ) {
                Text("Save Room", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextMuted)
            }
        },
        containerColor = ChamaraSurfaceDark
    )
}

@Composable
fun roomTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = ChamaraLime,
    unfocusedBorderColor = ChamaraBorder,
    focusedLabelColor = ChamaraLime,
    unfocusedLabelColor = TextMuted,
    cursorColor = ChamaraLime,
    focusedTextColor = TextWhite,
    unfocusedTextColor = TextWhite
)

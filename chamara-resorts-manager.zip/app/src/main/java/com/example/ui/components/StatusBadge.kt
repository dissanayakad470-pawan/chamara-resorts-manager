package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusAvailableBg
import com.example.ui.theme.StatusBalanceDue
import com.example.ui.theme.StatusBalanceDueBg
import com.example.ui.theme.StatusInProgress
import com.example.ui.theme.StatusInProgressBg
import com.example.ui.theme.StatusMaintenance
import com.example.ui.theme.StatusMaintenanceBg
import com.example.ui.theme.StatusOccupied
import com.example.ui.theme.StatusOccupiedBg
import com.example.ui.theme.StatusPaidCleared
import com.example.ui.theme.StatusPaidClearedBg
import com.example.ui.theme.StatusReserved
import com.example.ui.theme.StatusReservedBg

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, dotColor, label) = when (status.uppercase()) {
        "AVAILABLE" -> Quad(StatusAvailableBg, StatusAvailable, StatusAvailable, "AVAILABLE")
        "OCCUPIED" -> Quad(StatusOccupiedBg, StatusOccupied, StatusOccupied, "OCCUPIED")
        "RESERVED" -> Quad(StatusReservedBg, StatusReserved, StatusReserved, "RESERVED")
        "IN_PROGRESS", "ACTIVE" -> Quad(StatusInProgressBg, StatusInProgress, StatusInProgress, "IN PROGRESS")
        "BALANCE_DUE", "BALANCE DUE" -> Quad(StatusBalanceDueBg, StatusBalanceDue, StatusBalanceDue, "BALANCE DUE")
        "PAID", "CLEARED", "COMPLETED" -> Quad(StatusPaidClearedBg, StatusPaidCleared, StatusPaidCleared, "PAYMENT CLEARED")
        "MAINTENANCE" -> Quad(StatusMaintenanceBg, StatusMaintenance, StatusMaintenance, "MAINTENANCE")
        "CHECKOUT" -> Quad(StatusBalanceDueBg, StatusBalanceDue, StatusBalanceDue, "CHECKOUT")
        else -> Quad(Color(0xFF222B24), Color.White, Color.LightGray, status)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(0.8.dp, dotColor.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = label,
                color = textColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

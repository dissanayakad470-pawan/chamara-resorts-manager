package com.example.ui.screens.reports

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ChamaraBrandHeader
import com.example.ui.screens.dashboard.PaddingHeader
import com.example.ui.screens.dashboard.formatAmount
import com.example.ui.theme.ChamaraBgDark
import com.example.ui.theme.ChamaraBorder
import com.example.ui.theme.ChamaraLime
import com.example.ui.theme.ChamaraLimeBright
import com.example.ui.theme.ChamaraSurfaceCard
import com.example.ui.theme.ChamaraSurfaceDark
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusBalanceDue
import com.example.ui.theme.StatusOccupied
import com.example.ui.theme.StatusPaidCleared
import com.example.ui.theme.StatusReserved
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.ResortViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportsScreen(
    viewModel: ResortViewModel,
    modifier: Modifier = Modifier
) {
    val rooms by viewModel.allRooms.collectAsStateWithLifecycle()
    val bills by viewModel.allBills.collectAsStateWithLifecycle()
    val payments by viewModel.allPayments.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    val currency = settings.currencySymbol

    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    val monthStr = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())

    // Metrics calculations
    val todaySales = bills.filter { it.checkInDate == todayStr && it.status != "CANCELLED" }.sumOf { it.totalAmount }
    val todayCollections = payments.filter { it.paymentDate == todayStr }.sumOf { it.amount }

    val monthBills = bills.filter { it.checkInDate.startsWith(monthStr) && it.status != "CANCELLED" }
    val monthSales = monthBills.sumOf { it.totalAmount }
    val monthCollections = payments.filter { it.paymentDate.startsWith(monthStr) }.sumOf { it.amount }

    val totalOutstanding = bills.filter { it.status == "ACTIVE" }.sumOf { it.balance }

    // Occupancy
    val totalRooms = rooms.size
    val occupiedRooms = rooms.count { it.status.equals("OCCUPIED", ignoreCase = true) }
    val availableRooms = rooms.count { it.status.equals("AVAILABLE", ignoreCase = true) }
    val reservedRooms = rooms.count { it.status.equals("RESERVED", ignoreCase = true) }
    val occupancyRate = if (totalRooms > 0) (occupiedRooms.toFloat() / totalRooms) * 100 else 0f

    // Rental Type Breakdown
    val rentalTypes = listOf("Night", "Day", "Short Time", "Hourly")
    val breakdown = rentalTypes.map { type ->
        val typeBills = bills.filter { it.rentalType.equals(type, ignoreCase = true) && it.status != "CANCELLED" }
        val count = typeBills.size
        val revenue = typeBills.sumOf { it.totalAmount }
        Triple(type, count, revenue)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ChamaraBgDark),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        item {
            ChamaraBrandHeader(compact = true)
        }

        item {
            PaddingHeader(title = "FINANCIAL REPORTS & SALES")
        }

        // Today's Performance Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Today, contentDescription = null, tint = ChamaraLime, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("TODAY'S SUMMARY ($todayStr)", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ReportValueTile(
                            title = "Today's Invoiced",
                            value = "$currency ${formatAmount(todaySales)}",
                            sub = "Bills created today",
                            color = ChamaraLime,
                            modifier = Modifier.weight(1f)
                        )
                        ReportValueTile(
                            title = "Today's Cash Collected",
                            value = "$currency ${formatAmount(todayCollections)}",
                            sub = "${payments.count { it.paymentDate == todayStr }} Transactions",
                            color = StatusPaidCleared,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Monthly Performance Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = ChamaraLimeBright, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("CURRENT MONTH SUMMARY", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ReportValueTile(
                            title = "Monthly Revenue",
                            value = "$currency ${formatAmount(monthSales)}",
                            sub = "${monthBills.size} Bookings this month",
                            color = ChamaraLimeBright,
                            modifier = Modifier.weight(1f)
                        )
                        ReportValueTile(
                            title = "Monthly Collections",
                            value = "$currency ${formatAmount(monthCollections)}",
                            sub = "Paid receipts",
                            color = StatusPaidCleared,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Outstanding Balances Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (totalOutstanding > 0) StatusBalanceDue else ChamaraBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("TOTAL OUTSTANDING DUE", color = StatusBalanceDue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("$currency ${formatAmount(totalOutstanding)}", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        Text("From active guest stays", color = TextMuted, fontSize = 11.sp)
                    }
                    Icon(Icons.Default.MoneyOff, contentDescription = null, tint = StatusBalanceDue, modifier = Modifier.size(32.dp))
                }
            }
        }

        // Room Occupancy Statistics
        item {
            Spacer(modifier = Modifier.height(14.dp))
            PaddingHeader(title = "ROOM OCCUPANCY & CAPACITY")
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Current Occupancy Rate", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = "${String.format(Locale.US, "%.1f", occupancyRate)}%",
                            color = ChamaraLimeBright,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp
                        )
                    }

                    LinearProgressIndicator(
                        progress = { (occupancyRate / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = ChamaraLime,
                        trackColor = ChamaraSurfaceDark
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        OccupancyStatusLegend(label = "Available", count = availableRooms, color = StatusAvailable)
                        OccupancyStatusLegend(label = "Occupied", count = occupiedRooms, color = StatusOccupied)
                        OccupancyStatusLegend(label = "Reserved", count = reservedRooms, color = StatusReserved)
                        OccupancyStatusLegend(label = "Total Rooms", count = totalRooms, color = TextWhite)
                    }
                }
            }
        }

        // Rental Type Breakdown
        item {
            Spacer(modifier = Modifier.height(14.dp))
            PaddingHeader(title = "RENTAL TYPE BREAKDOWN (NIGHT / DAY / SHORT TIME / HOURLY)")
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    breakdown.forEach { (type, count, revenue) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(ChamaraSurfaceDark)
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "$type Rental", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(text = "$count Bookings Recorded", color = TextMuted, fontSize = 11.sp)
                            }
                            Text(
                                text = "$currency ${formatAmount(revenue)}",
                                color = ChamaraLime,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportValueTile(
    title: String,
    value: String,
    sub: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = ChamaraSurfaceDark,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(0.8.dp, ChamaraBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(6.dp))
            Text(value, color = color, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(sub, color = TextMuted, fontSize = 10.sp)
        }
    }
}

@Composable
fun OccupancyStatusLegend(label: String, count: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text("$label: $count", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

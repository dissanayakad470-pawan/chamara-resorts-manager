package com.example.ui.screens.bills

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.PaymentEntity
import com.example.data.entity.RentalBillEntity
import com.example.ui.screens.dashboard.PaddingHeader
import com.example.ui.screens.dashboard.RentalTypeBadge
import com.example.ui.screens.dashboard.formatAmount
import com.example.ui.screens.rooms.roomTextFieldColors
import com.example.ui.theme.ChamaraBgDark
import com.example.ui.theme.ChamaraBorder
import com.example.ui.theme.ChamaraGold
import com.example.ui.theme.ChamaraLime
import com.example.ui.theme.ChamaraLimeBright
import com.example.ui.theme.ChamaraSurfaceCard
import com.example.ui.theme.ChamaraSurfaceDark
import com.example.ui.theme.StatusBalanceDue
import com.example.ui.theme.StatusPaidCleared
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.ResortViewModel

@Composable
fun BillDetailScreen(
    billId: Long,
    viewModel: ResortViewModel,
    onBack: () -> Unit,
    onOpenInvoice: (RentalBillEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(billId) {
        viewModel.selectBill(billId)
    }

    val bill by viewModel.selectedBill.collectAsStateWithLifecycle()
    val payments by viewModel.selectedBillPayments.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    val currency = settings.currencySymbol

    var showAddPaymentDialog by remember { mutableStateOf(false) }
    var showCheckOutDialog by remember { mutableStateOf(false) }

    if (bill == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(ChamaraBgDark),
            contentAlignment = Alignment.Center
        ) {
            Text("Loading bill details...", color = TextMuted)
        }
        return
    }

    val currentBill = bill!!

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ChamaraBgDark),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // App bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text(currentBill.invoiceNumber, color = ChamaraLime, fontWeight = FontWeight.Black, fontSize = 16.sp)
                        Text(currentBill.roomNumber, color = TextLight, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }

                // Invoice / Print Button
                Button(
                    onClick = { onOpenInvoice(currentBill) },
                    colors = ButtonDefaults.buttonColors(containerColor = ChamaraLime, contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("view_invoice_button")
                ) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("View Invoice", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Guest & Stay Overview Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(currentBill.guestName, color = TextWhite, fontWeight = FontWeight.Black, fontSize = 18.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Call, contentDescription = null, tint = ChamaraLime, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(currentBill.guestPhone, color = TextMuted, fontSize = 12.sp)
                                if (currentBill.guestIdOrPassport.isNotBlank()) {
                                    Text(" • ID: ${currentBill.guestIdOrPassport}", color = TextDim, fontSize = 12.sp)
                                }
                            }
                        }

                        RentalTypeBadge(rentalType = currentBill.rentalType)
                    }

                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(ChamaraBorder))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Check-In", color = TextMuted, fontSize = 11.sp)
                            Text("${currentBill.checkInDate} ${currentBill.checkInTime}", color = TextLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Check-Out", color = TextMuted, fontSize = 11.sp)
                            Text(
                                if (currentBill.checkOutDate.isNotBlank()) "${currentBill.checkOutDate} ${currentBill.checkOutTime}" else "Active Stay",
                                color = if (currentBill.checkOutDate.isNotBlank()) TextLight else ChamaraLime,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // Financial Breakdown Card
        item {
            PaddingHeader(title = "FINANCIAL BREAKDOWN")
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DetailLine(
                        label = "Rental Fee (${currentBill.rentalType} @ $currency ${formatAmount(currentBill.ratePerUnit)} x ${currentBill.units})",
                        value = "$currency ${formatAmount(currentBill.roomCharge)}"
                    )

                    if (currentBill.extraCharges > 0) {
                        DetailLine(
                            label = "Extra Charges (${if (currentBill.extraChargesNote.isNotBlank()) currentBill.extraChargesNote else "Add-ons"})",
                            value = "+ $currency ${formatAmount(currentBill.extraCharges)}"
                        )
                    }

                    if (currentBill.discount > 0) {
                        DetailLine(
                            label = "Discount Given",
                            value = "- $currency ${formatAmount(currentBill.discount)}",
                            valueColor = ChamaraLime
                        )
                    }

                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(ChamaraBorder))

                    DetailLine(
                        label = "TOTAL INVOICE AMOUNT",
                        value = "$currency ${formatAmount(currentBill.totalAmount)}",
                        isBold = true,
                        valueColor = TextWhite
                    )

                    DetailLine(
                        label = "Total Paid to Date",
                        value = "$currency ${formatAmount(currentBill.paidAmount)}",
                        valueColor = StatusPaidCleared
                    )

                    // Outstanding highlight box
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (currentBill.balance > 0) StatusBalanceDue.copy(alpha = 0.15f) else StatusPaidCleared.copy(alpha = 0.15f))
                            .border(1.dp, if (currentBill.balance > 0) StatusBalanceDue.copy(alpha = 0.4f) else StatusPaidCleared.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (currentBill.balance > 0) "BALANCE DUE" else "ALL CHARGES CLEARED",
                            color = if (currentBill.balance > 0) StatusBalanceDue else StatusPaidCleared,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "$currency ${formatAmount(currentBill.balance)}",
                            color = if (currentBill.balance > 0) StatusBalanceDue else StatusPaidCleared,
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp
                        )
                    }
                }
            }
        }

        // Action Buttons: Add Payment & Check Out
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { showAddPaymentDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = ChamaraLime, contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("add_payment_button")
                ) {
                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Payment", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                if (currentBill.checkOutDate.isBlank()) {
                    OutlinedButton(
                        onClick = { showCheckOutDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StatusPaidCleared),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusPaidCleared),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("checkout_guest_button")
                    ) {
                        Icon(Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Check Out Guest", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // Payment Receipts History
        item {
            Spacer(modifier = Modifier.height(14.dp))
            PaddingHeader(title = "PAYMENT TRANSACTIONS & RECEIPTS")
        }

        if (payments.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No payment transactions recorded yet.", color = TextMuted, fontSize = 13.sp)
                }
            }
        } else {
            items(payments) { payment ->
                PaymentRowItem(payment = payment, currency = currency)
            }
        }
    }

    if (showAddPaymentDialog) {
        AddPaymentDialog(
            currentBalance = currentBill.balance,
            currency = currency,
            onDismiss = { showAddPaymentDialog = false },
            onConfirm = { amount, method, note ->
                viewModel.addPayment(currentBill.id, amount, method, note)
                showAddPaymentDialog = false
            }
        )
    }

    if (showCheckOutDialog) {
        AlertDialog(
            onDismissRequest = { showCheckOutDialog = false },
            title = { Text("Complete Check-Out?", color = TextWhite) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "This will finalize the guest stay for ${currentBill.roomNumber} (${currentBill.guestName}) and free the room back to AVAILABLE status.",
                        color = TextLight
                    )
                    if (currentBill.balance > 0) {
                        Text(
                            "NOTE: Guest still has an outstanding balance of $currency ${formatAmount(currentBill.balance)}. Please collect before departure!",
                            color = StatusBalanceDue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.checkOutGuest(currentBill.id)
                        showCheckOutDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ChamaraLime, contentColor = Color.Black)
                ) {
                    Text("Confirm Check-Out", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCheckOutDialog = false }) {
                    Text("Cancel", color = TextMuted)
                }
            },
            containerColor = ChamaraSurfaceDark
        )
    }
}

@Composable
fun DetailLine(
    label: String,
    value: String,
    isBold: Boolean = false,
    valueColor: Color = TextLight
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = if (isBold) TextWhite else TextMuted,
            fontSize = if (isBold) 13.sp else 12.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = value,
            color = valueColor,
            fontSize = if (isBold) 15.sp else 12.sp,
            fontWeight = if (isBold) FontWeight.ExtraBold else FontWeight.SemiBold
        )
    }
}

@Composable
fun PaymentRowItem(payment: PaymentEntity, currency: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ChamaraLime.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(payment.paymentMethod, color = ChamaraLimeBright, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("${payment.paymentDate} at ${payment.paymentTime}", color = TextMuted, fontSize = 11.sp)
                }
                if (payment.referenceNote.isNotBlank()) {
                    Text(payment.referenceNote, color = TextLight, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
                }
            }

            Text(
                text = "$currency ${formatAmount(payment.amount)}",
                color = StatusPaidCleared,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp
            )
        }
    }
}

@Composable
fun AddPaymentDialog(
    currentBalance: Double,
    currency: String,
    onDismiss: () -> Unit,
    onConfirm: (Double, String, String) -> Unit
) {
    var amountText by remember { mutableStateOf(if (currentBalance > 0) currentBalance.toInt().toString() else "0") }
    val paymentMethods = listOf("CASH", "CARD", "BANK_TRANSFER")
    var selectedMethod by remember { mutableStateOf("CASH") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Collect Payment", color = TextWhite, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Outstanding balance: $currency ${formatAmount(currentBalance)}",
                    color = if (currentBalance > 0) StatusBalanceDue else StatusPaidCleared,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Payment Amount ($currency)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = roomTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("payment_dialog_amount_input")
                )

                Column {
                    Text("Payment Method", color = TextMuted, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        paymentMethods.forEach { method ->
                            val isSelected = selectedMethod == method
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) ChamaraLime else ChamaraSurfaceDark)
                                    .clickable { selectedMethod = method }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = method,
                                    color = if (isSelected) Color.Black else TextLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Payment Reference / Receipt Note") },
                    placeholder = { Text("e.g. Card slip #1029, Cash advance") },
                    colors = roomTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    if (amount > 0) {
                        onConfirm(amount, selectedMethod, note.trim())
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ChamaraLime, contentColor = Color.Black),
                modifier = Modifier.testTag("payment_dialog_confirm_button")
            ) {
                Text("Confirm Payment", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextMuted)
            }
        },
        containerColor = ChamaraSurfaceDark
    )
}

package com.example.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.RentalBillEntity
import com.example.data.entity.RoomEntity
import com.example.ui.components.ChamaraBrandHeader
import com.example.ui.theme.ChamaraBgDark
import com.example.ui.theme.ChamaraBorder
import com.example.ui.theme.ChamaraGold
import com.example.ui.theme.ChamaraLime
import com.example.ui.theme.ChamaraLimeBright
import com.example.ui.theme.ChamaraSurfaceCard
import com.example.ui.theme.ChamaraSurfaceDark
import com.example.ui.theme.ChamaraSurfaceHover
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusBalanceDue
import com.example.ui.theme.StatusOccupied
import com.example.ui.theme.StatusPaidCleared
import com.example.ui.theme.StatusReserved
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.ResortViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: ResortViewModel,
    onNavigateToNewCheckIn: () -> Unit,
    onNavigateToRooms: () -> Unit,
    onNavigateToBills: () -> Unit,
    onSelectBill: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val rooms by viewModel.allRooms.collectAsStateWithLifecycle()
    val bills by viewModel.allBills.collectAsStateWithLifecycle()
    val payments by viewModel.allPayments.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    val currency = settings.currencySymbol

    val totalRooms = rooms.size
    val occupiedRooms = rooms.count { it.status.equals("OCCUPIED", ignoreCase = true) }
    val availableRooms = rooms.count { it.status.equals("AVAILABLE", ignoreCase = true) }
    val reservedRooms = rooms.count { it.status.equals("RESERVED", ignoreCase = true) }

    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    val todayBills = bills.filter { it.checkInDate == todayStr && it.status != "CANCELLED" }
    val todayRevenue = todayBills.sumOf { it.totalAmount }
    val todayPayments = payments.filter { it.paymentDate == todayStr }.sumOf { it.amount }

    val activeBills = bills.filter { it.status == "ACTIVE" }
    val totalOutstanding = activeBills.sumOf { it.balance }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ChamaraBgDark),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        item {
            ChamaraBrandHeader()
        }

        // Action Quick Bar: Check-In Button & Manage Rooms
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onNavigateToNewCheckIn,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ChamaraLime,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("dashboard_checkin_button")
                ) {
                    Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Check-In", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                OutlinedButton(
                    onClick = onNavigateToRooms,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("dashboard_rooms_button")
                ) {
                    Icon(Icons.Default.MeetingRoom, contentDescription = null, tint = ChamaraLime, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Rooms ($totalRooms)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
            }
        }

        // Metrics Grid
        item {
            PaddingHeader(title = "OPERATIONAL OVERVIEW")
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "OCCUPANCY",
                    value = "$occupiedRooms / $totalRooms",
                    sub = "$availableRooms Available",
                    icon = Icons.Default.Bed,
                    accentColor = if (occupiedRooms > 0) StatusOccupied else StatusAvailable,
                    modifier = Modifier.weight(1f)
                )

                MetricCard(
                    title = "TODAY'S SALES",
                    value = "$currency ${formatAmount(todayRevenue)}",
                    sub = "${todayBills.size} Bookings",
                    icon = Icons.Default.AttachMoney,
                    accentColor = ChamaraLime,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "TODAY'S CASH",
                    value = "$currency ${formatAmount(todayPayments)}",
                    sub = "Collections",
                    icon = Icons.Default.CalendarMonth,
                    accentColor = StatusPaidCleared,
                    modifier = Modifier.weight(1f)
                )

                MetricCard(
                    title = "BALANCE DUE",
                    value = "$currency ${formatAmount(totalOutstanding)}",
                    sub = "${activeBills.count { it.balance > 0 }} Unsettled",
                    icon = Icons.Default.MoneyOff,
                    accentColor = if (totalOutstanding > 0) StatusBalanceDue else StatusPaidCleared,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Room Status Bar
        item {
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                PaddingHeader(title = "ROOM AVAILABILITY STATUS", horizontalPadding = 0.dp)
                Text(
                    text = "View All",
                    color = ChamaraLime,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { onNavigateToRooms() }
                        .padding(4.dp)
                )
            }
        }

        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(rooms) { room ->
                    DashboardRoomChip(room = room, onNavigateToRooms = onNavigateToRooms)
                }
            }
        }

        // Active Stays / Recent Check-Ins
        item {
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                PaddingHeader(title = "ACTIVE STAYS & RECENT BILLS", horizontalPadding = 0.dp)
                Text(
                    text = "See All Bills",
                    color = ChamaraLime,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { onNavigateToBills() }
                        .padding(4.dp)
                )
            }
        }

        if (bills.isEmpty()) {
            item {
                EmptyStateCard(
                    message = "No bookings or check-ins yet. Tap 'New Check-In' above to create your first rental bill!",
                    onAction = onNavigateToNewCheckIn
                )
            }
        } else {
            items(bills.take(5)) { bill ->
                BillRowItem(
                    bill = bill,
                    currency = currency,
                    onClick = { onSelectBill(bill.id) }
                )
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    sub: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Text(
                text = value,
                color = TextWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black
            )

            Text(
                text = sub,
                color = accentColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun DashboardRoomChip(
    room: RoomEntity,
    onNavigateToRooms: () -> Unit
) {
    val statusColor = when (room.status.uppercase()) {
        "OCCUPIED" -> StatusOccupied
        "RESERVED" -> StatusReserved
        "MAINTENANCE" -> Color(0xFF6B7280)
        else -> StatusAvailable
    }

    Surface(
        modifier = Modifier
            .width(130.dp)
            .clickable { onNavigateToRooms() },
        shape = RoundedCornerShape(12.dp),
        color = ChamaraSurfaceCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = room.roomNumber,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = room.roomType,
                color = TextMuted,
                fontSize = 10.sp,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = room.status,
                color = statusColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun BillRowItem(
    bill: RentalBillEntity,
    currency: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .clickable { onClick() }
            .testTag("bill_item_${bill.invoiceNumber}"),
        colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = bill.invoiceNumber,
                        color = ChamaraLime,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "• ${bill.roomNumber}",
                        color = TextLight,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    RentalTypeBadge(rentalType = bill.rentalType)
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = bill.guestName,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Text(
                    text = "Check-in: ${bill.checkInDate} at ${bill.checkInTime}",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "$currency ${formatAmount(bill.totalAmount)}",
                    color = TextWhite,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                if (bill.balance > 0) {
                    Text(
                        text = "Due: $currency ${formatAmount(bill.balance)}",
                        color = StatusBalanceDue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                } else {
                    Text(
                        text = "Settled",
                        color = StatusPaidCleared,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = TextDim,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun RentalTypeBadge(rentalType: String) {
    val bgColor = when (rentalType.lowercase()) {
        "night" -> Color(0xFF1E3A8A)
        "day" -> Color(0xFF14532D)
        "short time" -> Color(0xFF581C87)
        "hourly" -> Color(0xFF713F12)
        else -> ChamaraSurfaceHover
    }
    val textColor = when (rentalType.lowercase()) {
        "night" -> Color(0xFF93C5FD)
        "day" -> Color(0xFF86EFAC)
        "short time" -> Color(0xFFD8B4FE)
        "hourly" -> Color(0xFFFDE047)
        else -> TextLight
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = rentalType,
            color = textColor,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun EmptyStateCard(
    message: String,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                Icons.Default.Receipt,
                contentDescription = null,
                tint = ChamaraLime,
                modifier = Modifier.size(36.dp)
            )
            Text(
                text = message,
                color = TextMuted,
                fontSize = 13.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
fun PaddingHeader(
    title: String,
    horizontalPadding: androidx.compose.ui.unit.Dp = 16.dp
) {
    Text(
        text = title,
        color = TextMuted,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(horizontal = horizontalPadding, vertical = 8.dp)
    )
}

fun formatAmount(amount: Double): String {
    return NumberFormat.getNumberInstance(Locale.US).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
    }.format(amount)
}

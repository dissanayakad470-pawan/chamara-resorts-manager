package com.example.ui.screens.bills

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ChamaraBrandHeader
import com.example.ui.screens.dashboard.BillRowItem
import com.example.ui.screens.dashboard.PaddingHeader
import com.example.ui.screens.rooms.roomTextFieldColors
import com.example.ui.theme.ChamaraBgDark
import com.example.ui.theme.ChamaraBorder
import com.example.ui.theme.ChamaraLime
import com.example.ui.theme.ChamaraSurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.ResortViewModel

@Composable
fun BillsScreen(
    viewModel: ResortViewModel,
    onSelectBill: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val bills by viewModel.filteredBills.collectAsStateWithLifecycle()
    val allBills by viewModel.allBills.collectAsStateWithLifecycle()
    val searchQuery by viewModel.billSearchQuery.collectAsStateWithLifecycle()
    val statusFilter by viewModel.billStatusFilter.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    val currency = settings.currencySymbol
    val filterOptions = listOf("ALL", "ACTIVE", "PAID", "CANCELLED")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ChamaraBgDark),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        item {
            ChamaraBrandHeader(compact = true)
        }

        item {
            PaddingHeader(title = "RENTAL BILLS & INVOICE ARCHIVE")
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setBillSearchQuery(it) },
                placeholder = { Text("Search by Guest, Room, Phone or Invoice #...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = ChamaraLime) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setBillSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextMuted)
                        }
                    }
                },
                colors = roomTextFieldColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .testTag("bills_search_input")
            )
        }

        // Status filter chips
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filterOptions) { filter ->
                    val isSelected = statusFilter == filter
                    val count = if (filter == "ALL") allBills.size else allBills.count { it.status.equals(filter, ignoreCase = true) }

                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setBillStatusFilter(filter) },
                        label = { Text("$filter ($count)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ChamaraLime,
                            selectedLabelColor = Color.Black,
                            containerColor = ChamaraSurfaceCard,
                            labelColor = TextMuted
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            borderColor = if (isSelected) ChamaraLime else ChamaraBorder,
                            enabled = true,
                            selected = isSelected
                        )
                    )
                }
            }
        }

        if (bills.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (searchQuery.isNotBlank()) "No bills found matching '$searchQuery'" else "No rental bills in this category.",
                        color = TextMuted,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            items(bills) { bill ->
                BillRowItem(
                    bill = bill,
                    currency = currency,
                    onClick = { onSelectBill(bill.id) }
                )
            }
        }
    }
}

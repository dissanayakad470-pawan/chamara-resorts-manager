package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChamaraBgDark
import com.example.ui.theme.ChamaraBorder
import com.example.ui.theme.ChamaraLime
import com.example.ui.theme.ChamaraLimeBright
import com.example.ui.theme.ChamaraSurfaceCard
import com.example.ui.theme.ChamaraSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

/**
 * Chamara Resorts visual branding header inspired by the official business card:
 * - Bright Lime Green lettering for "Chamara" with leaf accent
 * - Crisp White bold lettering for "Resort"
 * - Deep dark slate/green background
 * - Official telephone numbers and Vavuniya address
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChamaraBrandHeader(
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = ChamaraSurfaceDark,
        shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp)
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        colors = listOf(ChamaraSurfaceDark, ChamaraBgDark)
                    )
                )
                .padding(horizontal = 16.dp, vertical = if (compact) 12.dp else 16.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Logo and Brand Name
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(if (compact) 38.dp else 46.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(ChamaraSurfaceCard)
                                .border(1.5.dp, ChamaraLime, RoundedCornerShape(12.dp))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Eco,
                                contentDescription = "Chamara Resorts Logo Leaf",
                                tint = ChamaraLime,
                                modifier = Modifier.size(if (compact) 24.dp else 28.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Row(verticalAlignment = Alignment.Bottom) {
                                // "Chamara" in bright vibrant lime green
                                Text(
                                    text = "Chamara",
                                    color = ChamaraLimeBright,
                                    fontSize = if (compact) 22.sp else 28.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontStyle = FontStyle.Italic,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                // "Resort" in bold white
                                Text(
                                    text = "Resort",
                                    color = TextWhite,
                                    fontSize = if (compact) 20.sp else 26.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            }
                            Text(
                                text = "HOTEL ROOM RENTAL & BILLING",
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 1.5.sp
                            )
                        }
                    }

                    // Luxury Star Badge
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(ChamaraSurfaceCard)
                            .border(1.dp, ChamaraBorder, CircleShape)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = ChamaraLime,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Vavuniya",
                                color = ChamaraLime,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                if (!compact) {
                    Spacer(modifier = Modifier.height(12.dp))

                    // Contact & Location Pills
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ContactPill(
                            icon = Icons.Default.LocationOn,
                            text = "Kandy Road, Vavuniya",
                            tint = ChamaraLime
                        )
                        ContactPill(
                            icon = Icons.Default.Call,
                            text = "024 222 8059",
                            tint = TextWhite
                        )
                        ContactPill(
                            icon = Icons.Default.Call,
                            text = "077 335 5622",
                            tint = TextWhite
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ContactPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    tint: Color
) {
    Surface(
        color = ChamaraSurfaceCard,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, ChamaraBorder)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = text,
                color = TextWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

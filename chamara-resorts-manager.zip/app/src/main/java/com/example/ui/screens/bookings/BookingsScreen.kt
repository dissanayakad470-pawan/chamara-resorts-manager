package com.example.ui.screens.bookings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.RoomEntity
import com.example.ui.components.ChamaraBrandHeader
import com.example.ui.screens.dashboard.PaddingHeader
import com.example.ui.screens.dashboard.formatAmount
import com.example.ui.screens.rooms.roomTextFieldColors
import com.example.ui.theme.ChamaraBgDark
import com.example.ui.theme.ChamaraBorder
import com.example.ui.theme.ChamaraLime
import com.example.ui.theme.ChamaraLimeBright
import com.example.ui.theme.ChamaraSurfaceCard
import com.example.ui.theme.ChamaraSurfaceDark
import com.example.ui.theme.ChamaraSurfaceHover
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusBalanceDue
import com.example.ui.theme.StatusOccupied
import com.example.ui.theme.StatusPaidCleared
import com.example.ui.theme.TextLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.ResortViewModel

@Composable
fun BookingsScreen(
    viewModel: ResortViewModel,
    preselectedRoom: RoomEntity? = null,
    onSelectBill: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val rooms by viewModel.allRooms.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    val currency = settings.currencySymbol

    var selectedRoom by remember { mutableStateOf<RoomEntity?>(preselectedRoom) }

    LaunchedEffect(preselectedRoom, rooms) {
        if (selectedRoom == null && rooms.isNotEmpty()) {
            selectedRoom = preselectedRoom ?: rooms.firstOrNull { it.status == "AVAILABLE" } ?: rooms.firstOrNull()
        }
    }

    // Rental Type Selection: Night, Day, Short Time, Hourly
    val rentalTypes = listOf("Night", "Day", "Short Time", "Hourly")
    var selectedRentalType by remember { mutableStateOf("Night") }

    var unitsText by remember { mutableStateOf("1") }
    var customRateText by remember { mutableStateOf("") }

    // Update rate text whenever room or rental type changes
    LaunchedEffect(selectedRoom, selectedRentalType) {
        val room = selectedRoom
        if (room != null) {
            val defaultRate = when (selectedRentalType) {
                "Night" -> room.defaultNightRate
                "Day" -> room.defaultDayRate
                "Short Time" -> room.defaultShortTimeRate
                "Hourly" -> room.defaultHourlyRate
                else -> room.defaultNightRate
            }
            customRateText = defaultRate.toInt().toString()
        }
    }

    // Guest Info
    var guestName by remember { mutableStateOf("") }
    var guestPhone by remember { mutableStateOf("") }
    var guestIdOrPassport by remember { mutableStateOf("") }

    // Extra Charges & Discounts
    var extraChargesText by remember { mutableStateOf("0") }
    var extraChargesNote by remember { mutableStateOf("") }
    var discountText by remember { mutableStateOf("0") }

    // Payment Info
    var advancePaymentText by remember { mutableStateOf("0") }
    val paymentMethods = listOf("CASH", "CARD", "BANK_TRANSFER")
    var selectedPaymentMethod by remember { mutableStateOf("CASH") }
    var notes by remember { mutableStateOf("") }

    // Validation
    var validationError by remember { mutableStateOf<String?>(null) }

    // Calculated amounts
    val units = unitsText.toIntOrNull()?.coerceAtLeast(1) ?: 1
    val rate = customRateText.toDoubleOrNull() ?: 0.0
    val roomCharge = rate * units
    val extraCharges = extraChargesText.toDoubleOrNull() ?: 0.0
    val discount = discountText.toDoubleOrNull() ?: 0.0
    val totalAmount = (roomCharge + extraCharges - discount).coerceAtLeast(0.0)
    val advancePayment = advancePaymentText.toDoubleOrNull() ?: 0.0
    val balanceDue = (totalAmount - advancePayment).coerceAtLeast(0.0)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ChamaraBgDark),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        item {
            ChamaraBrandHeader(compact = true)
        }

        item {
            PaddingHeader(title = "NEW GUEST CHECK-IN & ROOM RENTAL")
        }

        // Section 1: Room Selector
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("1. SELECT ROOM / CABANA", color = ChamaraLime, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(rooms) { room ->
                            val isSelected = selectedRoom?.id == room.id
                            val isOccupied = room.status.equals("OCCUPIED", ignoreCase = true)

                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { selectedRoom = room },
                                color = if (isSelected) ChamaraLime else if (isOccupied) ChamaraSurfaceDark else ChamaraSurfaceDark,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) ChamaraLime else if (isOccupied) StatusOccupied.copy(alpha = 0.5f) else ChamaraBorder
                                )
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                    Text(
                                        text = room.roomNumber,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isSelected) Color.Black else TextWhite
                                    )
                                    Text(
                                        text = room.status,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSelected) Color.Black.copy(alpha = 0.8f) else if (isOccupied) StatusOccupied else StatusAvailable
                                    )
                                }
                            }
                        }
                    }

                    selectedRoom?.let { room ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(ChamaraSurfaceDark)
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.MeetingRoom, contentDescription = null, tint = ChamaraLime, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("${room.roomNumber} • ${room.roomType}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("${room.floor} | ${room.amenities}", color = TextMuted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Section 2: Rental Type & Duration
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("2. RENTAL TYPE & DURATION", color = ChamaraLime, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        rentalTypes.forEach { type ->
                            val isSelected = selectedRentalType == type
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedRentalType = type },
                                label = { Text(type, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ChamaraLime,
                                    selectedLabelColor = Color.Black,
                                    containerColor = ChamaraSurfaceDark,
                                    labelColor = TextMuted
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    borderColor = if (isSelected) ChamaraLime else ChamaraBorder,
                                    enabled = true,
                                    selected = isSelected
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = customRateText,
                            onValueChange = { customRateText = it },
                            label = { Text("Rate / Unit ($currency)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = roomTextFieldColors(),
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("checkin_rate_input")
                        )

                        OutlinedTextField(
                            value = unitsText,
                            onValueChange = { unitsText = it },
                            label = {
                                Text(
                                    when (selectedRentalType) {
                                        "Night" -> "Nights"
                                        "Day" -> "Days"
                                        "Short Time" -> "Stay Count"
                                        "Hourly" -> "Hours"
                                        else -> "Units"
                                    }
                                )
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = roomTextFieldColors(),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("checkin_units_input")
                        )
                    }
                }
            }
        }

        // Section 3: Guest Information
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("3. GUEST INFORMATION", color = ChamaraLime, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = guestName,
                        onValueChange = {
                            guestName = it
                            validationError = null
                        },
                        label = { Text("Guest Full Name *") },
                        placeholder = { Text("e.g. Mr. Kasun Perera") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = ChamaraLime) },
                        colors = roomTextFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("checkin_guest_name_input")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = guestPhone,
                            onValueChange = {
                                guestPhone = it
                                validationError = null
                            },
                            label = { Text("Phone Number *") },
                            placeholder = { Text("07X-XXXXXXX") },
                            leadingIcon = { Icon(Icons.Default.Call, contentDescription = null, tint = ChamaraLime) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            colors = roomTextFieldColors(),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("checkin_guest_phone_input")
                        )

                        OutlinedTextField(
                            value = guestIdOrPassport,
                            onValueChange = { guestIdOrPassport = it },
                            label = { Text("NIC / Passport") },
                            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = ChamaraLime) },
                            colors = roomTextFieldColors(),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("checkin_guest_nic_input")
                        )
                    }
                }
            }
        }

        // Section 4: Extra Charges & Add-ons
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("4. EXTRA CHARGES & DISCOUNTS", color = ChamaraLime, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = extraChargesText,
                            onValueChange = { extraChargesText = it },
                            label = { Text("Extra Charges ($currency)") },
                            placeholder = { Text("0.00") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = roomTextFieldColors(),
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = discountText,
                            onValueChange = { discountText = it },
                            label = { Text("Discount ($currency)") },
                            placeholder = { Text("0.00") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = roomTextFieldColors(),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = extraChargesNote,
                        onValueChange = { extraChargesNote = it },
                        label = { Text("Extra Items (e.g. Extra Bed, Dinner, Mini Bar)") },
                        colors = roomTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Section 5: Payment & Bill Summary
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = ChamaraSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ChamaraBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("5. BILL CALCULATION & ADVANCE PAYMENT", color = ChamaraLime, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = ChamaraSurfaceDark,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(0.8.dp, ChamaraBorder)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            BillSummaryLine(label = "Room Charges ($selectedRentalType x $units)", value = "$currency ${formatAmount(roomCharge)}")
                            if (extraCharges > 0) {
                                BillSummaryLine(label = "Add-ons / Extras", value = "+ $currency ${formatAmount(extraCharges)}")
                            }
                            if (discount > 0) {
                                BillSummaryLine(label = "Discount", value = "- $currency ${formatAmount(discount)}", valueColor = ChamaraLime)
                            }
                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(ChamaraBorder))
                            BillSummaryLine(
                                label = "NET TOTAL AMOUNT",
                                value = "$currency ${formatAmount(totalAmount)}",
                                isBold = true,
                                valueColor = TextWhite
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = advancePaymentText,
                            onValueChange = { advancePaymentText = it },
                            label = { Text("Advance Paid ($currency)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = roomTextFieldColors(),
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("checkin_advance_payment_input")
                        )

                        // Payment Method
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Payment Mode", color = TextMuted, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                paymentMethods.forEach { method ->
                                    val isSelected = selectedPaymentMethod == method
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isSelected) ChamaraLime else ChamaraSurfaceDark)
                                            .clickable { selectedPaymentMethod = method }
                                            .padding(horizontal = 6.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = when (method) {
                                                "CASH" -> "Cash"
                                                "CARD" -> "Card"
                                                else -> "Bank"
                                            },
                                            color = if (isSelected) Color.Black else TextLight,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Balance Display
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (balanceDue > 0) StatusBalanceDue.copy(alpha = 0.15f) else StatusPaidCleared.copy(alpha = 0.15f))
                            .border(1.dp, if (balanceDue > 0) StatusBalanceDue.copy(alpha = 0.4f) else StatusPaidCleared.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (balanceDue > 0) "REMAINING BALANCE DUE" else "FULLY PAID / SETTLED",
                            color = if (balanceDue > 0) StatusBalanceDue else StatusPaidCleared,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "$currency ${formatAmount(balanceDue)}",
                            color = if (balanceDue > 0) StatusBalanceDue else StatusPaidCleared,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp
                        )
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Special Requests / Stay Notes") },
                        colors = roomTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Validation Error Message
        if (validationError != null) {
            item {
                Text(
                    text = validationError ?: "",
                    color = StatusBalanceDue,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                )
            }
        }

        // Submit Button
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    val room = selectedRoom
                    if (room == null) {
                        validationError = "Please select a room."
                        return@Button
                    }
                    if (guestName.isBlank()) {
                        validationError = "Please enter guest full name."
                        return@Button
                    }
                    if (guestPhone.isBlank()) {
                        validationError = "Please enter guest contact number."
                        return@Button
                    }

                    viewModel.performCheckIn(
                        room = room,
                        guestName = guestName.trim(),
                        guestPhone = guestPhone.trim(),
                        guestIdOrPassport = guestIdOrPassport.trim(),
                        rentalType = selectedRentalType,
                        ratePerUnit = rate,
                        units = units,
                        extraCharges = extraCharges,
                        extraChargesNote = extraChargesNote.trim(),
                        discount = discount,
                        advancePayment = advancePayment,
                        paymentMethod = selectedPaymentMethod,
                        notes = notes.trim(),
                        onSuccess = { billId ->
                            onSelectBill(billId)
                        }
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ChamaraLime,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .height(54.dp)
                    .testTag("confirm_checkin_button")
            ) {
                Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Confirm Check-In & Issue Bill", fontWeight = FontWeight.Black, fontSize = 15.sp)
            }
        }
    }
}

@Composable
fun BillSummaryLine(
    label: String,
    value: String,
    isBold: Boolean = false,
    valueColor: Color = TextLight
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = if (isBold) TextWhite else TextMuted,
            fontSize = if (isBold) 13.sp else 12.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = value,
            color = valueColor,
            fontSize = if (isBold) 15.sp else 12.sp,
            fontWeight = if (isBold) FontWeight.ExtraBold else FontWeight.SemiBold
        )
    }
}

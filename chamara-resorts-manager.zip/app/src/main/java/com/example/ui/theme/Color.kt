package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Chamara Resorts Luxury Brand Palette
val ChamaraLime = Color(0xFFA3E635)         // Primary energetic resort lime
val ChamaraLimeBright = Color(0xFFBEF264)   // Bright neon lime accent
val ChamaraLimeDark = Color(0xFF4D7C0F)     // Deep olive lime for contrast
val ChamaraGold = Color(0xFFFACC15)         // Warm luxury gold for VIP / stars

val ChamaraBgDark = Color(0xFF0F1319)       // Deep charcoal slate background
val ChamaraSurfaceDark = Color(0xFF171C24)  // Elevated surface
val ChamaraSurfaceCard = Color(0xFF1E2430)  // Card container
val ChamaraSurfaceHover = Color(0xFF262E3D) // Interactive highlight surface
val ChamaraBorder = Color(0xFF2A3444)       // Subtle crisp border

val TextWhite = Color(0xFFF8FAFC)
val TextLight = Color(0xFFE2E8F0)
val TextMuted = Color(0xFF94A3B8)
val TextDim = Color(0xFF64748B)

// Operational Status Colors
val StatusAvailable = Color(0xFF10B981)     // Emerald green
val StatusAvailableBg = Color(0xFF064E3B)   // Deep emerald bg
val StatusOccupied = Color(0xFFF59E0B)      // Amber orange
val StatusOccupiedBg = Color(0xFF78350F)    // Deep amber bg
val StatusReserved = Color(0xFF06B6D4)      // Cyan blue
val StatusReservedBg = Color(0xFF164E63)    // Deep cyan bg
val StatusMaintenance = Color(0xFF6B7280)   // Slate gray
val StatusMaintenanceBg = Color(0xFF1F2937) // Deep slate bg
val StatusPaidCleared = Color(0xFF10B981)   // Emerald green
val StatusPaidClearedBg = Color(0xFF064E3B) // Deep emerald bg
val StatusBalanceDue = Color(0xFFF43F5E)    // Vivid rose / coral
val StatusBalanceDueBg = Color(0xFF881337)  // Deep rose bg
val StatusInProgress = Color(0xFF38BDF8)    // Sky blue
val StatusInProgressBg = Color(0xFF0C4A6E)  // Deep sky bg

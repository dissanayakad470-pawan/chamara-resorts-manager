package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.ResortDatabase
import com.example.data.entity.PaymentEntity
import com.example.data.entity.RentalBillEntity
import com.example.data.entity.ResortSettingsEntity
import com.example.data.entity.RoomEntity
import com.example.data.repository.ResortRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ResortViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ResortRepository

    init {
        val database = ResortDatabase.getInstance(application)
        repository = ResortRepository(database)
        viewModelScope.launch {
            repository.ensureInitialized()
        }
    }

    // Room filters
    private val _roomStatusFilter = MutableStateFlow("ALL")
    val roomStatusFilter: StateFlow<String> = _roomStatusFilter.asStateFlow()

    fun setRoomStatusFilter(status: String) {
        _roomStatusFilter.value = status
    }

    val allRooms: StateFlow<List<RoomEntity>> = repository.allRooms
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredRooms: StateFlow<List<RoomEntity>> = combine(allRooms, roomStatusFilter) { rooms, filter ->
        if (filter == "ALL") rooms
        else rooms.filter { it.status.equals(filter, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Bills & Filters
    private val _billSearchQuery = MutableStateFlow("")
    val billSearchQuery: StateFlow<String> = _billSearchQuery.asStateFlow()

    private val _billStatusFilter = MutableStateFlow("ALL")
    val billStatusFilter: StateFlow<String> = _billStatusFilter.asStateFlow()

    fun setBillSearchQuery(query: String) {
        _billSearchQuery.value = query
    }

    fun setBillStatusFilter(status: String) {
        _billStatusFilter.value = status
    }

    val allBills: StateFlow<List<RentalBillEntity>> = repository.allBills
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredBills: StateFlow<List<RentalBillEntity>> = combine(allBills, billSearchQuery, billStatusFilter) { bills, query, filter ->
        bills.filter { bill ->
            val matchesFilter = when (filter) {
                "ACTIVE" -> bill.status == "ACTIVE"
                "PAID" -> bill.status == "PAID"
                "CANCELLED" -> bill.status == "CANCELLED"
                else -> true
            }
            val matchesQuery = query.isBlank() ||
                    bill.guestName.contains(query, ignoreCase = true) ||
                    bill.roomNumber.contains(query, ignoreCase = true) ||
                    bill.invoiceNumber.contains(query, ignoreCase = true) ||
                    bill.guestPhone.contains(query, ignoreCase = true)

            matchesFilter && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val outstandingBills: StateFlow<List<RentalBillEntity>> = allBills.map { list ->
        list.filter { it.status == "ACTIVE" && it.balance > 0 }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Currently Selected Bill for Details
    private val _selectedBillId = MutableStateFlow<Long?>(null)
    val selectedBillId: StateFlow<Long?> = _selectedBillId.asStateFlow()

    fun selectBill(billId: Long) {
        _selectedBillId.value = billId
    }

    val selectedBill: StateFlow<RentalBillEntity?> = _selectedBillId.flatMapLatest { id ->
        if (id == null) flowOf(null)
        else repository.getBillByIdFlow(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedBillPayments: StateFlow<List<PaymentEntity>> = _selectedBillId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList())
        else repository.getPaymentsForBill(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPayments: StateFlow<List<PaymentEntity>> = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Settings
    val settings: StateFlow<ResortSettingsEntity> = repository.settings.map {
        it ?: ResortSettingsEntity()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ResortSettingsEntity())

    // Operations
    fun performCheckIn(
        room: RoomEntity,
        guestName: String,
        guestPhone: String,
        guestIdOrPassport: String,
        rentalType: String,
        ratePerUnit: Double,
        units: Int,
        extraCharges: Double,
        extraChargesNote: String,
        discount: Double,
        advancePayment: Double,
        paymentMethod: String,
        notes: String,
        onSuccess: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val billId = repository.createCheckIn(
                room = room,
                guestName = guestName,
                guestPhone = guestPhone,
                guestIdOrPassport = guestIdOrPassport,
                rentalType = rentalType,
                ratePerUnit = ratePerUnit,
                units = units,
                extraCharges = extraCharges,
                extraChargesNote = extraChargesNote,
                discount = discount,
                advancePayment = advancePayment,
                paymentMethod = paymentMethod,
                notes = notes
            )
            onSuccess(billId)
        }
    }

    fun addPayment(
        billId: Long,
        amount: Double,
        paymentMethod: String,
        referenceNote: String,
        onComplete: (Boolean) -> Unit = {}
    ) {
        viewModelScope.launch {
            val ok = repository.addPayment(billId, amount, paymentMethod, referenceNote)
            onComplete(ok)
        }
    }

    fun checkOutGuest(billId: Long, onComplete: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val ok = repository.checkOut(billId)
            onComplete(ok)
        }
    }

    fun cancelBill(billId: Long) {
        viewModelScope.launch {
            repository.cancelBill(billId)
        }
    }

    // Room management
    fun addRoom(room: RoomEntity) {
        viewModelScope.launch {
            repository.insertRoom(room)
        }
    }

    fun updateRoom(room: RoomEntity) {
        viewModelScope.launch {
            repository.updateRoom(room)
        }
    }

    fun deleteRoom(room: RoomEntity) {
        viewModelScope.launch {
            repository.deleteRoom(room)
        }
    }

    fun setRoomStatus(roomId: Long, status: String) {
        viewModelScope.launch {
            repository.setRoomStatus(roomId, status)
        }
    }

    fun updateSettings(updatedSettings: ResortSettingsEntity) {
        viewModelScope.launch {
            repository.saveSettings(updatedSettings)
        }
    }
}

package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.PaymentDao
import com.example.data.dao.RentalBillDao
import com.example.data.dao.SettingsDao
import com.example.data.dao.RoomDao
import com.example.data.entity.PaymentEntity
import com.example.data.entity.RentalBillEntity
import com.example.data.entity.ResortSettingsEntity
import com.example.data.entity.RoomEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        RoomEntity::class,
        RentalBillEntity::class,
        PaymentEntity::class,
        ResortSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ResortDatabase : RoomDatabase() {
    abstract fun roomDao(): RoomDao
    abstract fun rentalBillDao(): RentalBillDao
    abstract fun paymentDao(): PaymentDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var INSTANCE: ResortDatabase? = null

        fun getInstance(context: Context): ResortDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ResortDatabase::class.java,
                    "chamara_resorts.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            populateInitialData(getInstance(context))
                        }
                    }
                })
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun populateInitialData(database: ResortDatabase) {
            val roomDao = database.roomDao()
            val settingsDao = database.settingsDao()

            if (settingsDao.getSettingsSync() == null) {
                settingsDao.saveSettings(ResortSettingsEntity())
            }

            if (roomDao.getRoomCount() == 0) {
                val initialRooms = listOf(
                    RoomEntity(
                        roomNumber = "Room 101",
                        roomType = "Deluxe AC Double",
                        floor = "Ground Floor",
                        status = "AVAILABLE",
                        defaultNightRate = 8500.0,
                        defaultDayRate = 5000.0,
                        defaultShortTimeRate = 3500.0,
                        defaultHourlyRate = 1200.0,
                        amenities = "AC, King Bed, Hot Water, TV, Balcony",
                        notes = "Poolside view"
                    ),
                    RoomEntity(
                        roomNumber = "Room 102",
                        roomType = "Deluxe AC Double",
                        floor = "Ground Floor",
                        status = "AVAILABLE",
                        defaultNightRate = 8500.0,
                        defaultDayRate = 5000.0,
                        defaultShortTimeRate = 3500.0,
                        defaultHourlyRate = 1200.0,
                        amenities = "AC, King Bed, Hot Water, TV",
                        notes = "Garden view"
                    ),
                    RoomEntity(
                        roomNumber = "Room 201",
                        roomType = "Luxury Ocean View Suite",
                        floor = "1st Floor",
                        status = "AVAILABLE",
                        defaultNightRate = 12500.0,
                        defaultDayRate = 7500.0,
                        defaultShortTimeRate = 5000.0,
                        defaultHourlyRate = 1800.0,
                        amenities = "AC, King Bed, Jacuzzi, Ocean Balcony, Mini Bar",
                        notes = "VIP Ocean front"
                    ),
                    RoomEntity(
                        roomNumber = "Room 202",
                        roomType = "Standard Non-AC Double",
                        floor = "1st Floor",
                        status = "AVAILABLE",
                        defaultNightRate = 5500.0,
                        defaultDayRate = 3500.0,
                        defaultShortTimeRate = 2500.0,
                        defaultHourlyRate = 800.0,
                        amenities = "Ceiling Fan, Queen Bed, Attached Bath",
                        notes = "Quiet corner"
                    ),
                    RoomEntity(
                        roomNumber = "Villa A",
                        roomType = "Private Garden Villa",
                        floor = "Garden Wing",
                        status = "AVAILABLE",
                        defaultNightRate = 16000.0,
                        defaultDayRate = 9500.0,
                        defaultShortTimeRate = 6500.0,
                        defaultHourlyRate = 2500.0,
                        amenities = "Private Plunge Pool, 2 Bedrooms, Kitchenette, AC",
                        notes = "Family villa with garden"
                    ),
                    RoomEntity(
                        roomNumber = "Cabana 1",
                        roomType = "Eco Beach Cabana",
                        floor = "Beachfront",
                        status = "AVAILABLE",
                        defaultNightRate = 9500.0,
                        defaultDayRate = 6000.0,
                        defaultShortTimeRate = 4000.0,
                        defaultHourlyRate = 1500.0,
                        amenities = "King Bed, Open Sky Shower, Hammock, Sea Breeze",
                        notes = "Direct beach access"
                    )
                )
                roomDao.insertAllRooms(initialRooms)
            }
        }
    }
}

package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rooms")
data class RoomEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val roomNumber: String,
    val roomType: String, // "Deluxe Double", "Standard AC", "Luxury Suite", "Eco Cottage"
    val floor: String, // "Ground Floor", "1st Floor", "Garden Wing"
    val status: String = "AVAILABLE", // "AVAILABLE", "OCCUPIED", "RESERVED", "MAINTENANCE"
    val defaultNightRate: Double = 8500.0,
    val defaultDayRate: Double = 5000.0,
    val defaultShortTimeRate: Double = 3500.0,
    val defaultHourlyRate: Double = 1200.0,
    val amenities: String = "AC, King Bed, Hot Water, Wi-Fi",
    val notes: String = ""
)

@Entity(tableName = "rental_bills")
data class RentalBillEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNumber: String,
    val roomId: Long,
    val roomNumber: String,
    val guestName: String,
    val guestPhone: String,
    val guestIdOrPassport: String = "",
    val rentalType: String, // "Night", "Day", "Short Time", "Hourly"
    val ratePerUnit: Double,
    val units: Int = 1, // e.g. 1 night, 3 hours, 2 days
    val roomCharge: Double,
    val extraCharges: Double = 0.0,
    val extraChargesNote: String = "",
    val discount: Double = 0.0,
    val totalAmount: Double,
    val paidAmount: Double = 0.0,
    val balance: Double,
    val status: String = "ACTIVE", // "ACTIVE", "PAID", "CANCELLED"
    val checkInDate: String, // "yyyy-MM-dd"
    val checkInTime: String, // "HH:mm"
    val checkOutDate: String = "", // "yyyy-MM-dd"
    val checkOutTime: String = "", // "HH:mm"
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val billId: Long,
    val amount: Double,
    val paymentDate: String, // "yyyy-MM-dd"
    val paymentTime: String, // "HH:mm"
    val paymentMethod: String = "CASH", // "CASH", "CARD", "BANK_TRANSFER", "ONLINE"
    val referenceNote: String = ""
)

@Entity(tableName = "resort_settings")
data class ResortSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val resortName: String = "CHAMARA RESORTS",
    val resortAddress: String = "No. 1/10, 1st Lane, Kandy Road, Vavuniya",
    val telephone1: String = "024 222 8059",
    val telephone2: String = "077 335 5622",
    val currencySymbol: String = "Rs.",
    val defaultNightPrice: Double = 7500.0,
    val defaultDayPrice: Double = 5000.0,
    val defaultShortTimePrice: Double = 3500.0,
    val defaultHourlyPrice: Double = 1200.0,
    val invoicePrefix: String = "CR",
    val nextInvoiceSeq: Int = 1001,
    val invoiceFooterText: String = "Thank you for choosing CHAMARA RESORTS! We wish you a pleasant stay."
)

package com.example.data.repository

import com.example.data.database.ResortDatabase
import com.example.data.entity.PaymentEntity
import com.example.data.entity.RentalBillEntity
import com.example.data.entity.ResortSettingsEntity
import com.example.data.entity.RoomEntity
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ResortRepository(private val database: ResortDatabase) {
    private val roomDao = database.roomDao()
    private val billDao = database.rentalBillDao()
    private val paymentDao = database.paymentDao()
    private val settingsDao = database.settingsDao()

    // Room operations
    val allRooms: Flow<List<RoomEntity>> = roomDao.getAllRooms()

    fun getRoomsByStatus(status: String): Flow<List<RoomEntity>> = roomDao.getRoomsByStatus(status)

    suspend fun getRoomById(id: Long): RoomEntity? = roomDao.getRoomById(id)

    suspend fun insertRoom(room: RoomEntity): Long = roomDao.insertRoom(room)

    suspend fun updateRoom(room: RoomEntity) = roomDao.updateRoom(room)

    suspend fun deleteRoom(room: RoomEntity) = roomDao.deleteRoom(room)

    suspend fun setRoomStatus(roomId: Long, status: String) = roomDao.updateRoomStatus(roomId, status)

    // Bill operations
    val allBills: Flow<List<RentalBillEntity>> = billDao.getAllBills()

    fun getBillsByStatus(status: String): Flow<List<RentalBillEntity>> = billDao.getBillsByStatus(status)

    suspend fun getBillById(id: Long): RentalBillEntity? = billDao.getBillById(id)

    fun getBillByIdFlow(id: Long): Flow<RentalBillEntity?> = billDao.getBillByIdFlow(id)

    suspend fun getActiveBillForRoom(roomId: Long): RentalBillEntity? = billDao.getActiveBillForRoom(roomId)

    // Complete Check-In transaction
    suspend fun createCheckIn(
        room: RoomEntity,
        guestName: String,
        guestPhone: String,
        guestIdOrPassport: String,
        rentalType: String,
        ratePerUnit: Double,
        units: Int,
        extraCharges: Double,
        extraChargesNote: String,
        discount: Double,
        advancePayment: Double,
        paymentMethod: String,
        notes: String
    ): Long {
        val now = Date()
        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(now)
        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)

        val settings = settingsDao.getSettingsSync() ?: ResortSettingsEntity()
        val invoiceNumber = "${settings.invoicePrefix}-${settings.nextInvoiceSeq}"
        // increment invoice seq
        settingsDao.saveSettings(settings.copy(nextInvoiceSeq = settings.nextInvoiceSeq + 1))

        val roomCharge = ratePerUnit * units
        val subtotal = roomCharge + extraCharges
        val total = (subtotal - discount).coerceAtLeast(0.0)
        val initialPaid = advancePayment.coerceIn(0.0, total)
        val balance = (total - initialPaid).coerceAtLeast(0.0)
        val status = if (balance <= 0.0) "PAID" else "ACTIVE"

        val bill = RentalBillEntity(
            invoiceNumber = invoiceNumber,
            roomId = room.id,
            roomNumber = room.roomNumber,
            guestName = guestName,
            guestPhone = guestPhone,
            guestIdOrPassport = guestIdOrPassport,
            rentalType = rentalType,
            ratePerUnit = ratePerUnit,
            units = units,
            roomCharge = roomCharge,
            extraCharges = extraCharges,
            extraChargesNote = extraChargesNote,
            discount = discount,
            totalAmount = total,
            paidAmount = initialPaid,
            balance = balance,
            status = status,
            checkInDate = dateStr,
            checkInTime = timeStr,
            notes = notes
        )

        val billId = billDao.insertBill(bill)

        // Mark room as occupied
        roomDao.updateRoomStatus(room.id, "OCCUPIED")

        // Record initial payment if any
        if (initialPaid > 0) {
            paymentDao.insertPayment(
                PaymentEntity(
                    billId = billId,
                    amount = initialPaid,
                    paymentDate = dateStr,
                    paymentTime = timeStr,
                    paymentMethod = paymentMethod,
                    referenceNote = "Advance Payment on Check-In"
                )
            )
        }

        return billId
    }

    // Add payment to existing bill
    suspend fun addPayment(
        billId: Long,
        amount: Double,
        paymentMethod: String,
        referenceNote: String
    ): Boolean {
        val bill = billDao.getBillById(billId) ?: return false
        val now = Date()
        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(now)
        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)

        paymentDao.insertPayment(
            PaymentEntity(
                billId = billId,
                amount = amount,
                paymentDate = dateStr,
                paymentTime = timeStr,
                paymentMethod = paymentMethod,
                referenceNote = referenceNote
            )
        )

        val newPaid = bill.paidAmount + amount
        val newBalance = (bill.totalAmount - newPaid).coerceAtLeast(0.0)
        val newStatus = if (newBalance <= 0.0 && bill.status == "ACTIVE") "PAID" else bill.status

        billDao.updateBill(
            bill.copy(
                paidAmount = newPaid,
                balance = newBalance,
                status = newStatus
            )
        )
        return true
    }

    // Check out guest & free room
    suspend fun checkOut(billId: Long): Boolean {
        val bill = billDao.getBillById(billId) ?: return false
        val now = Date()
        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(now)
        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)

        billDao.updateBill(
            bill.copy(
                checkOutDate = dateStr,
                checkOutTime = timeStr,
                status = "PAID"
            )
        )
        // Free up room back to available
        roomDao.updateRoomStatus(bill.roomId, "AVAILABLE")
        return true
    }

    suspend fun cancelBill(billId: Long) {
        val bill = billDao.getBillById(billId) ?: return
        billDao.updateBill(bill.copy(status = "CANCELLED"))
        roomDao.updateRoomStatus(bill.roomId, "AVAILABLE")
    }

    // Payments
    fun getPaymentsForBill(billId: Long): Flow<List<PaymentEntity>> = paymentDao.getPaymentsForBill(billId)
    val allPayments: Flow<List<PaymentEntity>> = paymentDao.getAllPayments()

    // Settings
    val settings: Flow<ResortSettingsEntity?> = settingsDao.getSettings()

    suspend fun saveSettings(settings: ResortSettingsEntity) {
        settingsDao.saveSettings(settings)
    }

    suspend fun ensureInitialized() {
        ResortDatabase.populateInitialData(database)
    }
}

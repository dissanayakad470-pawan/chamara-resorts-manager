package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.PaymentEntity
import com.example.data.entity.RentalBillEntity
import com.example.data.entity.ResortSettingsEntity
import com.example.data.entity.RoomEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RoomDao {
    @Query("SELECT * FROM rooms ORDER BY roomNumber ASC")
    fun getAllRooms(): Flow<List<RoomEntity>>

    @Query("SELECT * FROM rooms WHERE status = :status ORDER BY roomNumber ASC")
    fun getRoomsByStatus(status: String): Flow<List<RoomEntity>>

    @Query("SELECT * FROM rooms WHERE id = :id LIMIT 1")
    suspend fun getRoomById(id: Long): RoomEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoom(room: RoomEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllRooms(rooms: List<RoomEntity>)

    @Update
    suspend fun updateRoom(room: RoomEntity)

    @Delete
    suspend fun deleteRoom(room: RoomEntity)

    @Query("UPDATE rooms SET status = :status WHERE id = :roomId")
    suspend fun updateRoomStatus(roomId: Long, status: String)

    @Query("SELECT COUNT(*) FROM rooms")
    suspend fun getRoomCount(): Int
}

@Dao
interface RentalBillDao {
    @Query("SELECT * FROM rental_bills ORDER BY createdAt DESC")
    fun getAllBills(): Flow<List<RentalBillEntity>>

    @Query("SELECT * FROM rental_bills WHERE status = :status ORDER BY createdAt DESC")
    fun getBillsByStatus(status: String): Flow<List<RentalBillEntity>>

    @Query("SELECT * FROM rental_bills WHERE id = :id LIMIT 1")
    suspend fun getBillById(id: Long): RentalBillEntity?

    @Query("SELECT * FROM rental_bills WHERE id = :id LIMIT 1")
    fun getBillByIdFlow(id: Long): Flow<RentalBillEntity?>

    @Query("SELECT * FROM rental_bills WHERE roomId = :roomId AND status = 'ACTIVE' LIMIT 1")
    suspend fun getActiveBillForRoom(roomId: Long): RentalBillEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBill(bill: RentalBillEntity): Long

    @Update
    suspend fun updateBill(bill: RentalBillEntity)

    @Delete
    suspend fun deleteBill(bill: RentalBillEntity)

    @Query("SELECT * FROM rental_bills WHERE checkInDate = :date AND status != 'CANCELLED'")
    fun getBillsForDate(date: String): Flow<List<RentalBillEntity>>
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments WHERE billId = :billId ORDER BY id DESC")
    fun getPaymentsForBill(billId: Long): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments ORDER BY id DESC")
    fun getAllPayments(): Flow<List<PaymentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentEntity): Long

    @Delete
    suspend fun deletePayment(payment: PaymentEntity)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM resort_settings WHERE id = 1 LIMIT 1")
    fun getSettings(): Flow<ResortSettingsEntity?>

    @Query("SELECT * FROM resort_settings WHERE id = 1 LIMIT 1")
    suspend fun getSettingsSync(): ResortSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: ResortSettingsEntity)
}

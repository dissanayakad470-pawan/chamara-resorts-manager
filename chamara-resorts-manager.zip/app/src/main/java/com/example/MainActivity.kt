package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.RentalBillEntity
import com.example.data.entity.RoomEntity
import com.example.ui.screens.bills.BillDetailScreen
import com.example.ui.screens.bills.BillsScreen
import com.example.ui.screens.bookings.BookingsScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.invoice.InvoiceScreen
import com.example.ui.screens.reports.ReportsScreen
import com.example.ui.screens.rooms.RoomsScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.theme.ChamaraBgDark
import com.example.ui.theme.ChamaraBorder
import com.example.ui.theme.ChamaraLime
import com.example.ui.theme.ChamaraResortsTheme
import com.example.ui.theme.ChamaraSurfaceCard
import com.example.ui.theme.ChamaraSurfaceDark
import com.example.ui.theme.TextLight
import com.example.ui.theme.TextMuted
import com.example.ui.viewmodel.ResortViewModel

enum class Screen {
    DASHBOARD,
    ROOMS,
    CHECK_IN,
    BILLS,
    BILL_DETAIL,
    INVOICE,
    REPORTS,
    SETTINGS
}

class MainActivity : ComponentActivity() {
    private val viewModel: ResortViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ChamaraResortsTheme {
                ChamaraApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun ChamaraApp(viewModel: ResortViewModel) {
    var currentScreen by remember { mutableStateOf(Screen.DASHBOARD) }
    var selectedRoomForCheckIn by remember { mutableStateOf<RoomEntity?>(null) }
    var selectedBillId by remember { mutableLongStateOf(0L) }
    var selectedBillForInvoice by remember { mutableStateOf<RentalBillEntity?>(null) }

    val showBottomBar = currentScreen != Screen.BILL_DETAIL && currentScreen != Screen.INVOICE

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ChamaraBgDark,
        bottomBar = {
            if (showBottomBar) {
                ChamaraBottomNavigation(
                    currentScreen = currentScreen,
                    onNavigate = { screen ->
                        if (screen == Screen.CHECK_IN) {
                            selectedRoomForCheckIn = null
                        }
                        currentScreen = screen
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(ChamaraBgDark)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    Screen.DASHBOARD -> DashboardScreen(
                        viewModel = viewModel,
                        onNavigateToNewCheckIn = {
                            selectedRoomForCheckIn = null
                            currentScreen = Screen.CHECK_IN
                        },
                        onNavigateToRooms = { currentScreen = Screen.ROOMS },
                        onNavigateToBills = { currentScreen = Screen.BILLS },
                        onSelectBill = { billId ->
                            selectedBillId = billId
                            currentScreen = Screen.BILL_DETAIL
                        }
                    )

                    Screen.ROOMS -> RoomsScreen(
                        viewModel = viewModel,
                        onBookRoom = { room ->
                            selectedRoomForCheckIn = room
                            currentScreen = Screen.CHECK_IN
                        }
                    )

                    Screen.CHECK_IN -> BookingsScreen(
                        viewModel = viewModel,
                        preselectedRoom = selectedRoomForCheckIn,
                        onSelectBill = { billId ->
                            selectedBillId = billId
                            currentScreen = Screen.BILL_DETAIL
                        }
                    )

                    Screen.BILLS -> BillsScreen(
                        viewModel = viewModel,
                        onSelectBill = { billId ->
                            selectedBillId = billId
                            currentScreen = Screen.BILL_DETAIL
                        }
                    )

                    Screen.BILL_DETAIL -> BillDetailScreen(
                        billId = selectedBillId,
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.BILLS },
                        onOpenInvoice = { bill: com.example.data.entity.RentalBillEntity ->
                            selectedBillForInvoice = bill
                            currentScreen = Screen.INVOICE
                        }
                    )

                    Screen.INVOICE -> {
                        val bill = selectedBillForInvoice
                        if (bill != null) {
                            InvoiceScreen(
                                bill = bill,
                                viewModel = viewModel,
                                onBack = { currentScreen = Screen.BILL_DETAIL }
                            )
                        } else {
                            currentScreen = Screen.BILLS
                        }
                    }

                    Screen.REPORTS -> ReportsScreen(
                        viewModel = viewModel
                    )

                    Screen.SETTINGS -> SettingsScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

data class NavItem(val screen: Screen, val title: String, val icon: ImageVector, val tag: String)

@Composable
fun ChamaraBottomNavigation(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit
) {
    val items = listOf(
        NavItem(Screen.DASHBOARD, "Overview", Icons.Default.Dashboard, "nav_dashboard"),
        NavItem(Screen.ROOMS, "Rooms", Icons.Default.MeetingRoom, "nav_rooms"),
        NavItem(Screen.CHECK_IN, "Check-In", Icons.Default.AddCircle, "nav_checkin"),
        NavItem(Screen.BILLS, "Bills", Icons.Default.Receipt, "nav_bills"),
        NavItem(Screen.REPORTS, "Reports", Icons.Default.Assessment, "nav_reports"),
        NavItem(Screen.SETTINGS, "Settings", Icons.Default.Settings, "nav_settings")
    )

    NavigationBar(
        containerColor = ChamaraSurfaceDark,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("bottom_nav_bar")
    ) {
        items.forEach { item ->
            val isSelected = currentScreen == item.screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(item.screen) },
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.title,
                        modifier = Modifier.size(20.dp)
                    )
                },
                label = {
                    Text(
                        text = item.title,
                        fontSize = 10.sp
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    selectedTextColor = ChamaraLime,
                    indicatorColor = ChamaraLime,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                ),
                modifier = Modifier.testTag(item.tag)
            )
        }
    }
}
